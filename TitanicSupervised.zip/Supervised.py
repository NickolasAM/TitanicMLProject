"""
Name: Nickolas Marquez
Date: 2/27/2025
Course: CS379
Description:
This script uses a RandomForestClassifier to predict whether a Titanic passenger survived.
It reads the data, cleans it up, splits it into training and test sets, trains a model,
checks how well the model does, and shows the results.
"""

# ----------------------------
# Import Libraries
# ----------------------------
import pandas as pd                     # For handling data in tables
import numpy as np                      # For doing math and working with numbers
import matplotlib.pyplot as plt         # For making plots and graphs
import seaborn as sns                   # For nicer looking graphs
from sklearn.ensemble import RandomForestClassifier  # Our model for prediction
from sklearn.model_selection import train_test_split # To split data into train/test sets
from sklearn.preprocessing import StandardScaler, LabelEncoder  # For scaling and turning text into numbers
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report  # To check how well our model does

# ----------------------------
# 1) Load the Data
# ----------------------------
# Point to where the Titanic CSV file is located
file_path = r'C:\Users\nicko\OneDrive\Desktop\titanicdata.csv'
# Read the CSV file into a DataFrame called "data"
data = pd.read_csv(file_path)

# Show the first few rows so we know what the data looks like
print(data.head())
# Print out the shape (rows and columns) of the dataset
print("Initial dataset shape:", data.shape)
# Check for any missing (empty) values in each column
print("\nMissing values in each column:\n", data.isnull().sum())

# ----------------------------
# 2) Clean and Prepare the Data
# ----------------------------
# Create a smaller DataFrame with just the columns we need:
# 'pclass', 'survived', 'sex', 'age', and 'fare'
df = data[['pclass', 'survived', 'sex', 'age', 'fare']].copy()

# Fix missing numbers:
# If there's a missing 'pclass', replace it with the median value of that column
df['pclass'] = df['pclass'].fillna(df['pclass'].median())
# Do the same for 'age' and 'fare'
df['age'] = df['age'].fillna(df['age'].median())
df['fare'] = df['fare'].fillna(df['fare'].median())

# Convert the 'sex' column from words (like 'male' or 'female') into numbers
df['sex'] = LabelEncoder().fit_transform(df['sex'])

# Remove any rows where we don't know if the passenger survived
df = df.dropna(subset=['survived'])

# Check again to make sure there are no missing values in our selected columns
print("\nMissing values after cleaning:\n", df.isnull().sum())

# ----------------------------
# 3) Set Up Features and Target
# ----------------------------
# X holds the input features (the stuff we use to predict)
X = df[['pclass', 'sex', 'age', 'fare']]
# y holds the target variable (what we want to predict: survived or not)
y = df['survived']

# ----------------------------
# 4) Scale the Features (Optional)
# ----------------------------
# We use StandardScaler to change the features so they're on a similar scale.
# This is not really needed for tree-based models like RandomForest,
# but it makes the data neat.
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ----------------------------
# 5) Split the Data
# ----------------------------
# Split the data into training (80%) and testing (20%) sets.
# This lets us train on one set of data and test on another.
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# ----------------------------
# 6) Train the Model
# ----------------------------
# Create our RandomForestClassifier model with a fixed random state (for repeatability)
rfc = RandomForestClassifier(random_state=42)
# Train the model using the training data
rfc.fit(X_train, y_train)

# ----------------------------
# 7) Evaluate the Model
# ----------------------------
# Use the trained model to predict survival on our test data
y_pred = rfc.predict(X_test)
# Calculate the accuracy (how many correct predictions)
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy: {:.2f}%".format(accuracy * 100))
# Create a confusion matrix to see where the model got things right or wrong
cm = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:\n", cm)
# Print a report showing precision, recall, and f1-score for more details
print("Classification Report:\n", classification_report(y_test, y_pred))

# ----------------------------
# 8) Visualize the Results
# ----------------------------
# Plot the confusion matrix as a heatmap to easily see model performance
plt.figure(figsize=(6, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()
