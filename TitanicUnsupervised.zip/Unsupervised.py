"""
Name: Nickolas Marquez
Date: 2/27/2025
Course: CS379
Description:
This script uses K-Means clustering to group Titanic passengers based on their class, gender, age, and fare.
We ignore the 'survived' column here because clustering is unsupervised and we don't use labeled outcomes.
"""

# ----------------------------
# Import Libraries
# ----------------------------
import pandas as pd                     # To handle our data in table form
import numpy as np                      # For doing math and number crunching
import matplotlib.pyplot as plt         # For making plots and graphs
import seaborn as sns                   # For nicer-looking graphs
from sklearn.cluster import KMeans      # For grouping data using K-Means clustering
from sklearn.preprocessing import StandardScaler, LabelEncoder  # For scaling features and converting text to numbers

# ----------------------------
# 1) Load the Data
# ----------------------------
# Specify where the Titanic CSV file is stored
file_path = r'C:\Users\nicko\OneDrive\Desktop\titanicdata.csv'
# Read the CSV file into a DataFrame named "data"
data = pd.read_csv(file_path)

# Show the first few rows so we can see what the data looks like
print(data.head())
# Print the size (rows and columns) of the dataset
print("Dataset shape:", data.shape)
# Check and print how many missing (empty) values are in each column
print("\nMissing values in each column:\n", data.isnull().sum())

# ----------------------------
# 2) Clean and Prepare the Data
# ----------------------------
# Create a smaller DataFrame called "df" with just the columns we need:
# 'pclass', 'sex', 'age', and 'fare'
df = data[['pclass', 'sex', 'age', 'fare']].copy()

# Fix missing values:
# If 'pclass' is missing, fill it with the median value of 'pclass'
df['pclass'] = df['pclass'].fillna(df['pclass'].median())
# If 'age' is missing, fill it with the median age
df['age'] = df['age'].fillna(df['age'].median())
# If 'fare' is missing, fill it with the median fare
df['fare'] = df['fare'].fillna(df['fare'].median())

# Convert the 'sex' column from words ('male'/'female') into numbers (like 1 and 0)
df['sex'] = LabelEncoder().fit_transform(df['sex'])

# Check again to make sure there are no empty values in these columns
print("\nMissing values after cleaning:\n", df.isnull().sum())

# ----------------------------
# 3) Scale the Features
# ----------------------------
# Standardize the data so all features have a mean of 0 and a standard deviation of 1.
# This helps the K-Means algorithm work better.
scaler = StandardScaler()
df_scaled = scaler.fit_transform(df)

# ----------------------------
# 4) Apply K-Means Clustering
# ----------------------------
# Create a KMeans model that will group our data into 2 clusters.
# We set a random_state so that we can reproduce the same results every time.
kmeans = KMeans(n_clusters=2, random_state=42)
# Fit the model on our scaled data and get the cluster labels for each data point
cluster_labels = kmeans.fit_predict(df_scaled)

# Add these cluster labels to our DataFrame as a new column called "Cluster"
df['Cluster'] = cluster_labels

# ----------------------------
# 5) Visualize the Clusters
# ----------------------------
# Create a scatter plot to show how the data is grouped.
# Here we plot "age" on the x-axis and "fare" on the y-axis, with colors showing the different clusters.
plt.figure(figsize=(8, 6))  # Set the size of the plot
sns.scatterplot(data=df, x='age', y='fare', hue='Cluster', palette='Set1')
plt.title('K-Means Clustering on Titanic Dataset (2 Clusters)')  # Title for the plot
plt.xlabel('Age')  # Label for x-axis
plt.ylabel('Fare')  # Label for y-axis
plt.legend(title='Cluster')  # Legend to show which color represents which cluster
plt.show()  # Display the plot
